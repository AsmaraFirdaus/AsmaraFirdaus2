@extends('main')
@section('title','home')
@section('container')

<img src="https://source.unsplash.com/1500x400" class="img-fluid" alt="...">
<figure class="text-center">
  <blockquote class="blockquote">
    <p>tampilan home</p>
  </blockquote>
  <figcaption class="blockquote-footer">
    Someone famous in <cite title="Source Title">Source Title</cite>
  </figcaption>
</figure>



<div class="card" style="width: 18rem;">
  <img src="https://source.unsplash.com/500x500" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"></h5>
    <p class="card-text">ini judul</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>


@endsection

